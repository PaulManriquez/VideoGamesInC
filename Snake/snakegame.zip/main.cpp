#include <iostream>

using namespace std;

#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

//----Rows Movement definition----
#define UP      72
#define DOWN    80
#define LEFT    75
#define RIGHT   77
#define ESC     27
int S_Dir=3; //Snake direction
//1 up
//2 down
//3 right
//4 left
//--------------------------------

using namespace std;

//---Snake Body---
#define MAXBODY 200
int SnakeBody[MAXBODY][2]={0};//Store the coordinates of the serpent, forming his body
int n=1;//start body of the snake --- from here start to refresh the coordinates        /*n*/
int S_size=8;//Actual snake size  --- till we get to the actual size                    /*tam*/
int x=10,y=12;//Initial snake position
//---Food--------
int xf=10 , yf=8;
//----------------

//---KEY Button---
char Key='\0';//Button key
int  velocity=100;
int  Score=0;
int  Level=1;

void ShowScore();//Head function


void gotoxy(int x,int y){//Set the cursor in that coordinate
    //Handle is a class to open a console
    HANDLE hCon;//hCon is the name of our object
           //To our console hCon we say that we want that, the console behaves like a display with "STD_OUTPUT_HANDLE", the opposite will be "STD_INPUT_HANDLE"
    hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD dwPos;//Object to set the coordinates
    dwPos.X = x;
    dwPos.Y = y;
                             //Object of the current console and Object of the Coordinates
    SetConsoleCursorPosition(hCon,dwPos);
}//----------------------------------------------------------------------------------------

void HideCursor(){//This function hides the cursor pointer of the console when is displayed
    HANDLE hCon;
    hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cci;//We create an object to set the information on how we want to display our cursor , this comes from "windows.h"
    cci.dwSize  = 1;//Set the size of the cursor
    cci.bVisible= FALSE;//Set invisible the cursor

    SetConsoleCursorInfo(hCon,&cci);//"SetConsoleCursorInfo" finally, tell to the console how to set
}//-----------------------------------------------------------------------------------------

void paint(){//This function start to print the borders in the console

    for(int x=2;x<78;x++){//---------------Horizontal line
        gotoxy(x,3);  printf("%c",205);//Upper border line
        gotoxy(x,23); printf("%c",205);//Lower border line
    }//---------------------------------------------------

    //---------------------------------Vertical border lines
    for(int y=4;y<23;y++){
        gotoxy(2,y);  printf("%c",186);//Left vertical line
        gotoxy(78,y);  printf("%c",186);//Right vertical line
    }
    //------------------------------------------------------
    gotoxy(2,3);    printf("%c",201);//Left Upper Corner
    gotoxy(2,23);   printf("%c",200);//Right Upper Corner
    gotoxy(78,3);   printf("%c",187);//Left Upper Corner
    gotoxy(78,23);  printf("%c",188);//Right Lower Corner

    //ShowScore();//Display Score and level
}

//------------------------------Snake--------------------------------------
//Continually saving the current position of the Snake, in while main block
void SaveSnakePos(){
    //   Update x and y coordinates
    SnakeBody[n][0]=x; SnakeBody[n][1]=y;
    n++;//Next coordinates
    if(n==S_size)n=1;//Reset
}//------------------------------------------------------------------------
void PaintSnake(){ /*DibujarCuerpo*/
    for(int i=1;i<S_size;i++){
        //Set on x and y coordinates and print
        gotoxy(SnakeBody[i][0],SnakeBody[i][1]); printf("*");
    }
}

void DeleteSnake(){/*borrar cuerpo*/
    gotoxy(SnakeBody[n][0],SnakeBody[n][1]); printf(" ");

}
//----------------------------------------------------------------------------

//----------------Food----------------
void ShowFood(){//Generate another random food in the board
    //Generate new food
    xf=4+rand()%72;
    yf=5+rand()%18;
    gotoxy(xf,yf); printf("%c",158);
}

bool EatingS(){//The snake have eaten?
    if((x == xf) && y == yf) return true;

    return false;
}//-----------------------------------

bool GameOver(){//Conditions to generate a game over
    if(y==3 || y==23 || x==2 || x==77) return true;

    for(int i=S_size-1;i>=1;i--){
        if(SnakeBody[i][0]==x && SnakeBody[i][1]==y) return true;
    }

    return false;
}//------------------------------------------------

void ShowScore(){
    gotoxy(82,3);printf("Score:%d",Score);
    gotoxy(82,5);printf("Level:%d",Level);
}

bool multiple50(){//Block to know if level up
    int copyScore=Score;
    while(copyScore>0){
        copyScore-=50;
    }
    if(copyScore==0) return true;
    return false;
}//------------------------------------------

//-----------Detect directions snake---------
void DirectionSnake(){
    if(kbhit()){//Check if a key was pressed
            Key=getch();
            switch(Key){
                case UP:
                    if(S_Dir!=2)
                        S_Dir=1;
                    break;
                case DOWN:
                    if(S_Dir!=1)
                        S_Dir=2;
                    break;
                case LEFT:
                    if(S_Dir!=3)
                        S_Dir=4;
                    break;
                case RIGHT:
                    if(S_Dir!=4)
                        S_Dir=3;
                    break;
                case 'a':
                    ShowFood();
                    break;
            }
        }
}//---------------------------------------------

void Title(){
        printf("\n\n");
        printf("\n\n");
        printf("  ********     **********>~            **********>~ \n\n");
        printf(" *  *****   ****    **       *       **    **   *******    \n");
        printf(" *  ****    ** **   **     ** **     **   **    **      \n");
        printf(" * **** *   **  **  **    **   **    ******     *******        \n");
        printf("  *****  *  **   ** **   ** *** **   **    **   **       \n");
        printf(" ********   **    ****  **       **  **     **  *******     \n");
        printf(" **********>~           *****>~       *******>~      \n\n");

        printf("     * *                                        \n");
        printf("      *                                       \n");
        printf("    *****                                         \n");
        printf("   * *** *                                    *     \n");
        printf("  *********                                  ***         \n");
        printf("  *********                                 *****          \n");
        printf("   *******                                 *****         \n");
        printf("    *****          **********               *****                \n");
        printf("     *****        *****    *****           *****                 \n");
        printf("      *****      *****      *****           *****                \n");
        printf("       *****    *****        *****        *****                  \n");
        printf("        ************          *****        *****                      \n");
        printf("          ********             *****        *****                \n");
        printf("           ******               ***** *****  ******                 \n");
        printf("                                ********************         \n");
        printf("                                  ****************        \n");
        gotoxy(19,15);printf("Press Start");


        system("pause>NULL");//Pause till press a key
        system("cls");//Clear display
}
void GameOverTitle(){
        gotoxy(2,2);
        printf("\n\n");
        printf("      ******        **     **      *** *******                 \n");
        printf("     **            ****    ** ** ** ** **                       \n");
        printf("    **   *****    **  **   **  ***  ** *******                  \n  ");
        printf("   **     **   ********  **       ** **                         \n");
        printf("      ********  **      ** **       ** *******                  \n ");
        printf("\n");
        printf("       *****    **         **  *******  ********                \n");
        printf("     **     **   **       **   **       **   **                 \n");
        printf("    **       **    **    **    *******  ** ***                  \n  ");
        printf("   **     **      **  **     **       **   **                   \n");
        printf("       *****          **       *******  **    **                \n ");
}

void DeleteAllScreen(){
    for(int x=0;x<110;x++){
        for(int y=0;y<24;y++){
            gotoxy(x,y); printf(" ");
        }
    }
}


int main(){
    srand(time(NULL));

    Title();

    paint();//Paint board
    ShowFood();//First food

    while(Key!=ESC && !GameOver()){//While ESC is not pressed

        if(EatingS()){//If the snake have eaten
            ShowFood();//Generate a new food
            S_size++;//Increment size of the snake
            Score+=10;
            if(multiple50() && velocity>=10) {Level++; velocity-=10;}//Each 50 points increase the velocity
        }


        DeleteSnake();

        SaveSnakePos();
        PaintSnake();
        ShowScore();

        DirectionSnake();//Execute the actual direction of the snake
        DirectionSnake();//We perform two actions of this function if we press quickly another key
        if(S_Dir==1){y--; Sleep(30);}
        if(S_Dir==2){y++; Sleep(30);}
        if(S_Dir==3) x++;
        if(S_Dir==4) x--;//------------------------------------------

        //-----------
        HideCursor();
        Sleep(velocity);
    }
    DeleteAllScreen();
    GameOverTitle();
    system("pause>null");
    return 0;
}


