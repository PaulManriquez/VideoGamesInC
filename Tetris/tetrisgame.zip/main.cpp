//Tetris Game project
//Programmer Paul Manriquez December 2023
//Documentation about miniwin https://miniwin.readthedocs.io/en/latest/Utilizacion.html
#include "miniwin.h"
#include <cstdlib>
#include <ctime>
#include <sstream>
#include <string.h>

#include "Zpiece.h"
#include "Square.h"
using namespace miniwin;
using namespace std;

#define ROWS 20
#define COLS 10

typedef struct Coor{//Coordinates struct
    int x,y;
}Coor;//-------------------------------

typedef struct CoorPiece{//Coordinates of the piece-----THIS IS MY PIECE
    Coor central;       //Central piece
    Coor Relatives[3]; //Relative Coordinates
    int  Color;       //Set the color of the piece

    Coor Position(int n);//Return the relative coordinate of the 4 squares
}CoorPiece;//-----------------------------------------------------------

Coor CoorPiece::Position(int n){
    Coor ret={central.x,central.y};
    if(n!=0){
        ret.x+=Relatives[n-1].x;
        ret.y+=Relatives[n-1].y;
    }
    return ret;
}//-----------------------------------------------------------------------
                 // X     Y
typedef int Board[COLS][ROWS];//x move through cols | y move through rows
//The board was based on "vredimensiona()"
//Thats why we "invert" how we implement the conventional way of Rows and Cols
//************************************************************************

void ShowPiece(CoorPiece &P){//----------Print the piece on screen----In the coordinates that receive print 4 squares according to the figure
    color(P.Color);
    for(int i=0;i<4;i++){
        Coor c=P.Position(i);//Retrieve the coordinates relatively already
        square(c.x,c.y);         //Print the square
        }
}//---------------------------------------------------------------

//**************************************************************************************
Coor Rotate(Coor &P){//Rotate a coordinate according to the original clock wise
    Coor P_={-P.y,P.x};
    return  P_;
}//-----------------------------------------------------------------------

void Rotate_Right(CoorPiece &P){//-------Execute the changes to rotate each coordinate
    for(int i=0;i<3;i++){
        P.Relatives[i]=Rotate(P.Relatives[i]);
    }
}//-----------------------------------------------------------------------------------
//***************************************************************************************

void emptyBoard(Board &T){//Fill with black spaces the coordinates-of this form we will know where is empty space, since Negro equals to 0
    for(int i=0;i<COLS;i++){
        for(int j=0;j<ROWS;j++){
            T[i][j]=NEGRO;//Since negro is a enum, we can store it in the matrix, empty square
        }
    }
}//------------------------------------------------------------------------------------

void PaintBoard(const Board &T){//--Paint the board-(according to the actual coordinates)
    for(int i=0;i<COLS;i++){
        for(int j=0;j<ROWS;j++){
            color(T[i][j]);//Paint the color according the "enum" is in the matrix
            square(i,j);  //Invoke the square
        }
    }
}//------------------------------------------------------------------------------------
              //Where you'll set the piece in the board | Coordinates to form the piece  < Not being used >
void Set_Piece(Board &T, CoorPiece &P){//Set a new piece in the board
    for(int i=0;i<4;i++){
        Coor c=P.Position(i);//Retrieve the coordinate to set the square color
        T[c.x][c.y]=P.Color;//Set the color of the square in that position
    }
}//---Since our board is a matrix, what does this function is, "go to the coordinate and set that color"

bool Collided(Board &T,CoorPiece &P){//Return true or false if the piece collided
    for(int i=0;i<4;i++){
        Coor c=P.Position(i);
        if(c.x < 0 || c.x >= COLS )//Board limits
            return true;
        if(c.y < 0 || c.y >= ROWS )//Board limits
            return true;
        if(T[c.x][c.y]!=NEGRO)//Collision with a piece of the board
            return true;
    }
    return false;//If there is no collision
}//-------------------------------------------------------------------------------

//------------------------Make a new piece----------------------------------------
Coor MRelatives[7][3]={//This are relative coordinates to form the pieces
                 {{-1,-1},{0,-1},{1,0}},/*Z*/
                 {{-1,0},{0,1},{-1,1}},/*O*/
                 {{-1,0},{-2,0},{1,0}},/*I*/
                 {{1,0},{0,1},{-1,1}},/*S*/
                 {{-1,0},{-1,1},{1,0}},/*L*/
                 {{-1,0},{1,0},{1,1}},/*J*/
                 {{-1,0},{1,0},{0,1}}/*T*/
};

void CreateNewPiece(CoorPiece &NewPiece){//Create a new Random piece | pieza nueva
    //NewPiece={ {3,5},{ {-1,-1},{0,-1},{1,0}},BLANCO};
    NewPiece.central.x=13; NewPiece.central.y=2;//Start point of the new piece

    int R= (rand()%7);//Generate a random number to generate a new figure from "Mrelatives"
    NewPiece.Color= 1+(rand()%6);//Random color set

    for(int i=0;i<3;i++){//Fill Relative coordinates
        NewPiece.Relatives[i]=MRelatives[R][i];
    }//---------------------------------------------
}
//-----------------------------------------------------------------------------------

//----------------------Detect if a line was filled----------------------------------

bool LineFilled(Board &T, int Row){//Return true or false is a line was filled | tableroFilaLLena
        for(int i=0;i<COLS;i++){
            if(T[i][Row]==NEGRO) return false;//Cheack one by one if a coordinate in x is NEGRO, if it is
        }                                    //it will tell us , that that line - is NOT filled or Yes
        return true;
}//------------------------------------------------------------------------------------------------------

void DeleteLine(Board &T,int Row){//Delete a line when is true starting from that row | Tablero colapsa
    /*
        This function delete a line in the row that is in the parameter
    */

    //Copy the upper line of the actual Row
    for(int i=Row;i>=0;i--){
        for(int j=0;j<COLS;j++){
         T[j][i] = T[j][i-1];
        }
    }
    //Empty the last upper line
    for(int j=0;j<COLS;j++){
        T[j][0]=NEGRO;
    }
}//--------------------------------------------------------------------------------------------------------

int Collapse(Board &T){//Delete all the possible lines in a row | tablero cuenta lineas
    /*
        This function pass through all the Board and if it detects that in that line needs to be deleted
        do the process and check all the possible lines to delete
    */
    int cont=0; //Lines deleted
    int Row=ROWS-1;

    while(Row>=0){//Check each line
        if(LineFilled(T,Row)){//If detect a line filled
            DeleteLine(T,Row);//Delete that line
            cont++;//Count of the lines deleted in this set of piece
        }else{
            Row--;//One row minus to check
        }
    }
    return cont;//Return the count of lines deleted
}
//-------------------------------------------------------------------

string toString(int points){//Convert the integer to a string
    stringstream sout;
    sout<< points;
    return sout.str();
}//------------------------------------------------------------

void ShowAll(Board &T, CoorPiece &NewPiece, CoorPiece &NextPiece,int points, int level){ //show each possible change in the board | repinta

    /*This function show all the possible changes happening in the board*/

    borra();//Clean buffer images from the screen
    PaintBoard(T);//Print the board (actual image)

    color_rgb(192,192,192);//Silver color
    linea(20,20,20,20 + SIZE_SQUARE*ROWS);//| Left
    linea(20 + SIZE_SQUARE*COLS,20,20 + SIZE_SQUARE*COLS,20 + SIZE_SQUARE*ROWS );//| right
    linea(20,20 + SIZE_SQUARE*ROWS,20 + SIZE_SQUARE*COLS,20 + SIZE_SQUARE*ROWS);//_ Down
    color(BLANCO);
    texto(25 + SIZE_SQUARE*COLS,20, "Next piece");
    texto(25 + SIZE_SQUARE*COLS,150,"Level");
    texto(25 + SIZE_SQUARE*COLS,150,"Level");
    texto(25 + SIZE_SQUARE*COLS + 50,150,toString(level+1));
    texto(25 + SIZE_SQUARE*COLS,220,"Points");
    texto(25 + SIZE_SQUARE*COLS + 50,220,toString(points));

    ShowPiece(NewPiece);//Set a new piece in the board
    ShowPiece(NextPiece);//Show the new piece in the board
    refresca();//Update changes
}

//Level table - points to pass to the next level
const int PointsT[5]={50,100,250,300,400};

//Permutation Table - set the velocity , depending on the level on how are falling down the pieces
const int PermutationTable[5]={25,20,15,10,5};

int main(){         //          COLS             ROWS
                   //           width   and      length
    vredimensiona(SIZE_SQUARE * COLS +220, SIZE_SQUARE * ROWS +50);//width and height of the console
                                    //Lateral space | Down space
    Board T; //Declare the board
    emptyBoard(T);//Fill with NEGRO color
    int key=tecla();//key function returns a integer
    srand(time(0));//Seed Random number according to the time
    int cont=0;//Counter of the lines eliminated
    int permutations=0;//while permutations counter
    int points=0;//Points by complete a line
    int level=0;//Level game
                        //Central coordinates | Relative Coordinates | Color
    //CoorPiece Z_Piece={ {3,5},{ {-1,-1},{0,-1},{1,0}},BLANCO};
      CoorPiece NewPiece,Copy,NextPiece;
      CreateNewPiece(NewPiece); CreateNewPiece(NextPiece);//Create a new piece and the next piece to start
      NewPiece.central.x=5;     NextPiece.central.x=13; NextPiece.central.y=2;
    //-------------------------------------------------------------------------------------

    borra();//Delete screen
    //PaintBoard(T);//Print the board
    //ShowPiece(NewPiece);//Show piece in the screen
    //refresca();//ReFresh
    ShowAll(T,NewPiece,NextPiece,points,level);
    //**


    while(key!=ESCAPE){//Escape is a num

        Copy = NewPiece;//Assign a new copy,this to save the old position of our piece

        if(permutations>=PermutationTable[level] && key==NINGUNA){//This makes down the piece each 20 miniseconds
            permutations=0;//reset
            key=ABAJO;
        }//-------------------------------------------------------------------------------

        //-------------Normal movement--------------
        if      (key==ABAJO)    NewPiece.central.y++;
        else if (key==ARRIBA)   NewPiece.central.y--;
        else if (key==IZQUIERDA)NewPiece.central.x--;
        else if (key==DERECHA)  NewPiece.central.x++;
        //------------------------------------------

        if(key==ESPACIO){//Rotate is ESPACIO is pressed
            Rotate_Right(NewPiece);
        }//--------------------------------------------

        //----------When detect a collision---------
        if(Collided(T,NewPiece)){//If was a collision
            NewPiece=Copy;//Step back to the old position
            if(key==ABAJO){//Set a piece in the board if the piece was downwards and detect a collision
                Set_Piece(T,NewPiece);//Set the new piece in the board
                cont=Collapse(T);//Check if that piece trigger to a delete the lines
                points+=cont*10;//Increment points according with the number of lines deleted
                if(points>PointsT[level] && level<5) level++;//Increment the level if the points are enough to pass to the next
                NewPiece=NextPiece;//The new piece will be the next in the row
                CreateNewPiece(NextPiece);//Generate a new piece
                NewPiece.central.x=5;

                //------GAME OVER-------
                if(Collided(T,NewPiece)){//When the piece again collide when appears again, you lose
                    texto(140,240,"GAME OVER");//Show in the screen
                    refresca();//Set the changes
                    espera(2000);//Wait 2 seconds
                    vcierra();//Close the console
                }
            }
        }//-----------------------------------------


        //--If nothing is being press, show in the screen------
        if(key !=NINGUNA){//If the key equals to not be pressed
            ShowAll(T,NewPiece,NextPiece,points,level);//Show in the screen all the possible changes in the board
        }//----------------------------------------------------

        key=tecla();//Detect when a key is press
        espera(20);//each 20 miniseconds
        permutations++;//Increase one
     }
    vcierra();
   return 0;
}

