//Developing a game
//Programmer Paul Manriquez November 2023
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include <list>
using namespace std;

//----Rows Movement definition----
#define UP      72
#define DOWN    80
#define LEFT    75
#define RIGHT   77
//--------------------------------

//What is the diference between .c .cpp and .h
using namespace std;

void gotoxy(int x,int y){//Set the cursor in that coordinate
    //Handle is a class to open a console
    HANDLE hCon;//hCon is the name of our object
           //To our console hCon we say that we want that that console behaves like a display with "STD_OUTPUT_HANDLE", the opposite will be "STD_INPUT_HANDLE"
    hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD dwPos;//Object to set the coordinates
    dwPos.X = x;
    dwPos.Y = y;
                             //Object of the current console and Object of the Coordinates
    SetConsoleCursorPosition(hCon,dwPos);
}//----------------------------------------------------------------------------------------

void HideCursor(){//This function hides the cursor pointer of the console when is displayed
    HANDLE hCon;
    hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cci;//We create an object to set the information on how we want to display our cursor , this comes from "windows.h"
    cci.dwSize  = 0;//Set the size of the cursor
    cci.bVisible= FALSE;//Set invisible the cursor

    SetConsoleCursorInfo(hCon,&cci);//"SetConsoleCursorInfo" finally, tell to the console how to set
}//-----------------------------------------------------------------------------------------

void BorderGame(){//-------------------------Set the limits of the border game
    for(int i=2;i<78;i++){//Set the horizontal lines - Above and below
        gotoxy(i,3);  printf("%c",205);
        gotoxy(i,33); printf("%c",205);
    }//---------------------------------------------------------------

    for(int i=4;i<33;i++){//Set the vertical lines, Left and Right
        gotoxy(2,i);  printf("%c",186);
        gotoxy(77,i); printf("%c",186);
    }//-----------------------------------------------------------

    gotoxy(2,3);   printf("%c",201);//Upper Left Corner
    gotoxy(77,3);  printf("%c",187);//Upper Right Corner
    gotoxy(2,33);  printf("%c",200);//Lower Left Corner
    gotoxy(77,33); printf("%c",188);//Lower Right Corner
}//----------------------------------------------------------------------------


//---------------------Set the Ship class---------------------
class Ship{
    private:
        int x,y;     //Coordinates of the ship
        int Heart;  //Health of the ship
        int Life;  //Number of life's
    public:
        Ship(int _x, int _y,int _Heart, int _Life): x(_x),y(_y),Heart(_Heart),Life(_Life){}//CONSTRUCTOR
    //---Getters---
    int GetX(){return x;};
    int GetY(){return y;};
    int GetLife(){return Life;};
    //---Methods---
    void ShowShip();
    void DeleteShip();
    void MoveShip();
    void ShowHearts();
    void DeathShip();
    void HeartDecrement(){Heart--;}
};

void Ship::ShowShip(){
    gotoxy(x,y);    printf("  %c",30);
    gotoxy(x,y+1);  printf(" %c%c%c",40,207,41);
    gotoxy(x,y+2);  printf("%c%c %c%c",30,190,190,30);
}

void Ship::DeleteShip(){
    gotoxy(x,y);    printf("             ");
    gotoxy(x,y+1);  printf("             ");
    gotoxy(x,y+2);  printf("             ");
    gotoxy(x,y+3);  printf("             ");
    gotoxy(x,y+4);  printf("             ");
    gotoxy(x,y+5);  printf("             ");
}

void Ship::MoveShip(){
    //"kbhit" from conio.h library detects if a key has been press
    char key='\0';
    if(kbhit()){
        key=getch();//Retrieve the character and sets to key
        DeleteShip();//Before you move you need to delete the old space on where was the ship
        if(key==LEFT  &&   x>5)x--;//----Movement---
        if(key==RIGHT &&  (x+14)<77)x++;
        if(key==UP    &&   y>6)y--;
        if(key==DOWN  &&  (y+7)<33)y++;//---------------
        if(key=='b'   )Heart--;
        ShowShip();//Now that you are in your place you can move
        ShowHearts();//Display the current health on screen
    }
}

void Ship::ShowHearts(){
    gotoxy(50,2); printf("Life's:%d",Life);
    gotoxy(64,2); printf("Health:");
    gotoxy(70,2); printf("   ");
    for(int i=0;i<Heart;i++){
        gotoxy(70+i,2); printf("%c ",3);
    }
}

void Ship::DeathShip(){
    if(Heart==0){
        DeleteShip();
        gotoxy(x,y);   printf("        ");
        gotoxy(x,y+1); printf("   **   ");
        gotoxy(x,y+2); printf(" ****** ");
        gotoxy(x,y+3); printf("   **   ");
        gotoxy(x,y+4); printf("        ");
        Sleep(300);
        DeleteShip();

        gotoxy(x,y);     printf("        ");
        gotoxy(x,y+1);   printf("  *   * ");
        gotoxy(x,y+2);   printf(" *  *  *");
        gotoxy(x,y+3);   printf("  *   * ");
        gotoxy(x,y+4);   printf("        ");
        Sleep(300);
        DeleteShip();

        gotoxy(x,y);     printf("*       *");
        gotoxy(x,y+1);   printf("  *   * ");
        gotoxy(x,y+2);   printf(" *  *  *");
        gotoxy(x,y+3);   printf("  *   * ");
        gotoxy(x,y+4);   printf("*       *");
        Sleep(300);
        DeleteShip();
        Life--;
        Heart=3;
        ShowHearts();
        ShowShip();
    }
}
//----------------------END SHIP CLASS----------------------------------------

//----------------------Asteroid class----------------------------------------
class Asteroid{
   private:
       int x,y;
   public:
       Asteroid(int _x,int _y):x(_x),y(_y){}//Constructor
       //-----Getters----
       int GetX(){return x;}
       int GetY(){return y;}
       //-----Methods----
       void ShowAsteroid();
       void MoveAsteroid();
       void Collision(class Ship &MyShip);
};

void Asteroid::ShowAsteroid(){
    gotoxy(x,y); printf("%c",184);
}

void Asteroid::MoveAsteroid(){
    gotoxy(x,y); printf(" ");
    y++;
    if(y>32){//Maximum coordinate number in y
             //Define range:71 is our maximum coordinate in x
        x = (rand()%71)+4;
        y = 4;
    }
    ShowAsteroid();
}

void Asteroid::Collision(class Ship &MyShip){

    //If the asteroid is in the space is being occupy by the ship in x and y
    if( x >=MyShip.GetX() && x <MyShip.GetX()+6
        && y >=MyShip.GetY() && y<=MyShip.GetY()+2){
        MyShip.DeleteShip();
        MyShip.HeartDecrement();//If a collision happen with an asteroid, the heart is decremented
        MyShip.ShowHearts();
        MyShip.ShowShip();//If a collision occurs paint again the ship,This because we are occupying space for the asteroid and erase our ship when pass through

        x=rand()%71+4;//If there is a collision with the asteroid, the asteroid takes another random value to appear in other place
        y=4;//---------------------------------------------------------------------------------------------------------------------
    }
}
//---------------------------End Asteroid Class------------------------------------------------------------------------------------

//-------------------------------Bullet Class--------------------------------------------------------------------------------------
class Bullet{
    private:
        int x,y;
    public:
    Bullet(int _x,int _y): x(_x),y(_y){}
    //---Getters----
    int GetX(){return x;}
    int GetY(){return y;}
    //-----Methods----
    void Shot();
    bool BulletOut();//Means that the bullet reach to the end of the upper border line
};

void Bullet::Shot(){
    gotoxy(x,y);printf(" ");

    if(y>4)y--;//If is in the range you can shot
    gotoxy(x,y); printf("%c",254);
}

bool Bullet::BulletOut(){
    if(y==4) return true;
    return false;
}

int main(){
    //---Variables---
    bool GameOver=false;
    int  Points=0;
    //---------------------Ship-----------------------------
    Ship MyShip(35,25,3,3);//Set our object in the coordinates 7,7
         MyShip.ShowShip();
         MyShip.ShowHearts();
    //--------------------Asteroid--------------------------
    //Asteroid MyAsteroid1(10,4); Asteroid MyAsteroid3(35,4);
    //Asteroid MyAsteroid2(70,4); Asteroid MyAsteroid4(50,4);
    list<Asteroid*> AsteroidList;
    list<Asteroid*>::iterator P_Asteroid;
    for(int i=0;i<5;i++){
        AsteroidList.push_back( new Asteroid( rand()%75+3, rand()%5+4));
    }
    //------------------------------------------------------
    //--------------------Bullet----------------------------
    list<Bullet*> Shot;//Double Linked List that stores objects bullet
    list<Bullet*>::iterator P;//Pointer to the object of the double linked list
    //------------------------------------------------------

    BorderGame();
    HideCursor();

    while(!GameOver){
        gotoxy(4,2); printf("Points:%d",Points);

        //Bullet
        if(kbhit()){//If a key is press
            char key=getch();
            if(key==32){//Every time space is press it will create a new shot object
                Shot.push_back(new Bullet( MyShip.GetX()+2,MyShip.GetY()-1) );
            }
        }
        for(P=Shot.begin(); P!=Shot.end();P++){//Here when the key is press create the object
            //Send the instruction to go upwards
            (*P)->Shot();//**What makes the animation is the while cycle since is always executing, the object created move and move , but not in this for cycle, but it get executed in the while cycle
            if( (*P)->BulletOut()){//If the bullet reach to the end of the upper line

                gotoxy( (*P)->GetX(),(*P)->GetY() ); printf(" ");//First delete the bullet from screen
                delete(*P);//Delete the actual object
                P=Shot.erase(P);//***This makes to point to the next object***
            }
        }
        //------

        //Asteroids
        //MyAsteroid1.MoveAsteroid(); MyAsteroid3.MoveAsteroid();
        //MyAsteroid2.MoveAsteroid(); MyAsteroid4.MoveAsteroid();
        //MyAsteroid1.Collision(MyShip); MyAsteroid3.Collision(MyShip);
        //MyAsteroid2.Collision(MyShip); MyAsteroid4.Collision(MyShip);
        for(P_Asteroid=AsteroidList.begin(); P_Asteroid!=AsteroidList.end();P_Asteroid++){
            (*P_Asteroid)->MoveAsteroid();
            (*P_Asteroid)->Collision(MyShip);
        }
        //--------------------------------------------------------------------------------

        //---------Detect collisions between a shot and asteroid--------
        for(P_Asteroid=AsteroidList.begin(); P_Asteroid!=AsteroidList.end();P_Asteroid++){
                for(P=Shot.begin();P!=Shot.end();P++){
                    if( (*P_Asteroid)->GetX()==(*P)->GetX() && ( (*P_Asteroid)->GetY()+1==(*P)->GetY()  || //In this case are about to collision the shot and the asteroid,so if they are just to one move to collision, that is a case of collision
                         (*P_Asteroid)->GetY()== (*P)->GetY() )  ){//In this case both are in the same position, so they have collided

                        gotoxy( (*P)->GetX(), (*P)->GetY() ); printf(" ");//Erase the shot
                        delete(*P);//Delete the object of the list
                        P=Shot.erase(P);//Retrieve where to point the next object in the list

                        //Delete asteroid
                        AsteroidList.push_back(new Asteroid( rand()%74+3,4) );//Create another object of the asteroid
                        gotoxy((*P_Asteroid)->GetX(), (*P_Asteroid)->GetY() );printf(" ");//Erase the actual asteroid colliding
                        delete( *P_Asteroid);
                        P_Asteroid=AsteroidList.erase(P_Asteroid);//Retrieve where to point the next element

                        Points+=10;
                    }

                }
        }//--------------------------------------End Detect Shot Collisions with Asteroids--------------------------------------

        //GameOver
        if(MyShip.GetLife()==0){GameOver=true;}

        //Ship
        MyShip.MoveShip();
        MyShip.DeathShip();
        Sleep(30);//This is to let the console rest for a moment since we don't need a lot of iterations to perform well the program
    }


    return 0;
}

